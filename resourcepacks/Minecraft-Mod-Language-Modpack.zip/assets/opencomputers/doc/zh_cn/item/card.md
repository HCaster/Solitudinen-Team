# 卡

![Can't be read.](oredict:oc:materialCard)

通用合成组件 ( [显卡](graphicsCard1.md) [网卡](lanCard.md)等等).
