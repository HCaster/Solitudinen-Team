# Transistor

![I think I've used up all my references.](oredict:oc:materialTransistor)

晶体管是基本合成材料，主要用于合成 [芯片](chip1.md)等电子产品.