# 数据库升级

![Living in the database.](oredict:oc:databaseUpgrade1)

可以配置为存储一系列物品信息, 进而被其他组件所用. 尤其是那种名字一样但是NBT标签不一样的物品, 回调里面并不会作为物品描述符的一部分.

配置数据库, 首先右键打开.把你想配置的物品放在上面的物品栏，会存储一个假的物品

也可以被
[物品栏控制器](inventoryControllerUpgrade.md) 和[扫描器](../block/geolyzer.md)的组件API配置
